import logging
import traceback

from fastapi import FastAPI, APIRouter, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi.errors import RateLimitExceeded
from slowapi import _rate_limit_exceeded_handler

import config
from db import client, db

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s | %(message)s")
logger = logging.getLogger("roviq-ai")

app = FastAPI(title="Roviq Ai", version="1.0.0")
api = APIRouter(prefix="/api")

# Rate limiting
from ratelimit import limiter
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Routers
from routers import auth as auth_router
from routers import businesses as biz_router
from routers import knowledge as kb_router
from routers import chat as chat_router
from routers import conversations as conv_router
from routers import analytics as ana_router
from routers import billing as billing_router
from routers import referrals as ref_router
from routers import owner_chat as oc_router
from routers import admin as admin_router
from routers import api_keys as api_keys_router
from routers import public_api as public_api_router
from routers import legal as legal_router
from routers import tickets as tickets_router
from routers import sales as sales_router
from routers import notifications as notifications_router
from storage import init_storage
from auth import seed_admin
from scheduler import start_scheduler, stop_scheduler

for r in [
    auth_router.router, biz_router.router, kb_router.router, chat_router.router,
    conv_router.router, ana_router.router, billing_router.router,
    ref_router.router, oc_router.router, admin_router.router,
    api_keys_router.router, public_api_router.router, legal_router.router,
    tickets_router.router, sales_router.router, notifications_router.router,
]:
    api.include_router(r)


@api.get("/")
async def root():
    return {"service": "Roviq Ai", "status": "ok"}


@api.get("/health")
async def health():
    """Enhanced health endpoint with full system status"""
    from services.health_monitor import get_health_monitor
    
    monitor = get_health_monitor()
    health_status = monitor.get_health_status()
    
    return health_status


@api.get("/metrics")
async def metrics():
    """Performance metrics endpoint"""
    from services.health_monitor import get_health_monitor
    
    monitor = get_health_monitor()
    return monitor.get_performance_report()


app.include_router(api)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=config.CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    # The customer-facing widget page (served by the frontend at /widget/{id} and
    # /talk/{id}, not by this backend) is DESIGNED to be embedded in an <iframe>
    # on any third-party business website. This backend has no HTML routes of its
    # own to exempt, but the check is kept in case a future route serves one.
    path = request.url.path
    if not (path.startswith("/widget/") or path.startswith("/talk/")):
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
    return response


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """Avoid leaking stack traces / internals to clients in production."""
    from services.health_monitor import get_health_monitor
    
    monitor = get_health_monitor()
    monitor.record_error(type(exc).__name__, str(exc), {"path": request.url.path, "method": request.method})
    
    logger.error("Unhandled exception on %s %s: %s", request.method, request.url.path, exc)
    if not config.IS_PRODUCTION:
        logger.error(traceback.format_exc())
        return JSONResponse(status_code=500, content={"detail": str(exc)})
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


@app.on_event("startup")
async def startup():
    backend = init_storage()
    logger.info("Storage initialized (%s backend)", backend)
    # Indexes
    await db.users.create_index("user_id", unique=True)
    await db.users.create_index("email", unique=True)
    await db.businesses.create_index("business_id", unique=True)
    await db.businesses.create_index("owner_user_id")
    await db.knowledge_chunks.create_index([("business_id", 1)])
    await db.conversations.create_index([("business_id", 1), ("created_at", -1)])
    await db.conversations.create_index([("business_id", 1), ("archived", 1), ("last_message_at", -1)])
    await db.messages.create_index([("conversation_id", 1)])
    await db.messages.create_index([("business_id", 1), ("text", 1)])
    await db.files.create_index("business_id")
    await db.notifications.create_index([("business_id", 1), ("created_at", -1)])
    await db.referrals.create_index("code", unique=True)
    await db.payment_orders.create_index("razorpay_order_id", unique=True)
    await db.invoices.create_index([("business_id", 1), ("created_at", -1)])
    await db.invoices.create_index("invoice_number", unique=True)
    await db.counters.create_index("id", unique=True)
    await db.appointments.create_index([("business_id", 1), ("start_time", 1)])
    await db.appointments.create_index("reference")
    await db.sessions.create_index("id", unique=True)
    await db.sessions.create_index("user_id")
    await db.sessions.create_index("refresh_token_hash")
    await db.sessions.create_index("prev_refresh_token_hash")
    await db.login_events.create_index([("user_id", 1), ("created_at", -1)])
    await db.api_keys.create_index("id", unique=True)
    await db.api_keys.create_index("key_hash")
    await db.api_keys.create_index([("business_id", 1), ("status", 1)])
    await db.api_key_usage.create_index([("key_id", 1), ("created_at", -1)])
    await db.legal_documents.create_index([("doc_type", 1), ("version", -1)])
    await db.legal_documents.create_index([("doc_type", 1), ("is_published", 1)])
    await db.enterprise_leads.create_index([("created_at", -1)])
    await db.tickets.create_index([("business_id", 1), ("created_at", -1)])
    await db.tickets.create_index([("status", 1), ("priority", -1)])
    await db.notifications_system.create_index([("target_group", 1), ("created_at", -1)])
    await db.notifications_system.create_index([("user_id", 1), ("read", 1), ("created_at", -1)])
    await db.sales_referrals.create_index([("sales_user_id", 1), ("status", 1)])
    await db.sales_referrals.create_index([("business_id", 1)], unique=True)
    await db.password_reset_otps.create_index([("user_id", 1), ("used", 1), ("expires_at", -1)])
    await db.password_reset_otps.create_index("email")
    await seed_admin()
    start_scheduler()
    logger.info("Indexes ensured; admin seed checked")


@app.on_event("shutdown")
async def shutdown():
    stop_scheduler()
    client.close()


# make db accessible to routers via app.state
app.state.db = db
