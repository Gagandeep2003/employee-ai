"""Reference schema for what's actually stored in each Mongo collection.

NOT used for runtime validation -- each router defines its own narrower Pydantic
input models for request bodies. This file exists purely as living documentation
of the document shape, kept in sync by hand when a router adds/changes a field.
"""
from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone
import uuid


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: EmailStr
    name: str
    picture: Optional[str] = None
    role: str = "owner"  # owner | admin
    referral_code: str
    referred_by_code: Optional[str] = None
    created_at: str = Field(default_factory=now_iso)


class Business(BaseModel):
    model_config = ConfigDict(extra="ignore")
    business_id: str
    owner_user_id: str
    name: str
    website: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    category: Optional[str] = None
    country: Optional[str] = None
    language: str = "en"
    timezone: str = "UTC"
    crawl_status: str = "pending"  # pending | crawling | done | error
    crawl_progress: int = 0
    knowledge_score: int = 0
    plan: str = "free"  # free | starter | pro
    monthly_limit: int = 100
    monthly_used: int = 0
    usage_period: str = ""  # "YYYY-MM" -- monthly_used rolls over when this no longer matches the current month (see usage.py)
    overage_count: int = 0  # chats past monthly_limit this period, billed at next renewal if overage_billing_enabled
    # GST -- optional; if unset, invoices default to IGST (conservative) and omit a buyer GSTIN.
    gst_state_code: Optional[str] = None  # 2-digit GST state code, see gst.py
    gstin: Optional[str] = None
    billing_legal_name: Optional[str] = None
    billing_address: Optional[str] = None
    # Subscription lifecycle -- see routers/billing.py and scheduler.py's billing_lifecycle_job
    subscription_status: str = "active"  # active | past_due | canceled
    current_period_end: Optional[str] = None  # ISO date; None on the free plan
    grace_period_ends_at: Optional[str] = None
    cancel_at_period_end: bool = False
    pending_plan_change: Optional[str] = None  # a downgrade scheduled to take effect at period end
    ai_snapshot: Optional[str] = None  # AI-generated overview of the business, shown during onboarding review
    ai_snapshot_generated_at: Optional[str] = None
    appointment_settings: Dict[str, Any] = Field(default_factory=lambda: {
        "enabled": False,
        "services": [],  # [{"name": str, "duration_minutes": int}]
        "working_hours": {d: None for d in ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]},  # [open,"HH:MM"]/[close,"HH:MM"] or None if closed
        "slot_interval_minutes": 30,
    })
    widget: Dict[str, Any] = Field(default_factory=lambda: {
        "primary_color": "#1E3F33",
        "accent_color": "#C4A47C",
        "welcome_message": "Hi there! I'm Roviq Ai. How can I help you today?",
        "position": "bottom-right",
        "logo_url": None,
        "show_branding": True,
    })
    created_at: str = Field(default_factory=now_iso)


class KnowledgeChunk(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    business_id: str
    text: str
    source: str  # url | file:{name} | manual
    source_title: Optional[str] = None
    tokens: List[str] = []  # lowercase tokens for BM25
    created_at: str = Field(default_factory=now_iso)


class Conversation(BaseModel):
    conversation_id: str
    business_id: str
    visitor_id: str
    status: str = "open"  # open | escalated | closed
    unanswered: bool = False
    outcome: Optional[str] = None  # None | lead | booked | resolved | lost -- owner-tagged, or "booked" auto-set on a successful appointment
    created_at: str = Field(default_factory=now_iso)
    last_message_at: str = Field(default_factory=now_iso)
    message_count: int = 0


class Appointment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    reference: str  # "APT-XXXXXX", shown to the customer for lookups/cancellation
    business_id: str
    service: str
    customer_name: str
    customer_phone: Optional[str] = None
    customer_email: Optional[str] = None
    start_time: str  # ISO 8601
    end_time: str
    status: str = "confirmed"  # confirmed | cancelled
    conversation_id: Optional[str] = None
    created_at: str = Field(default_factory=now_iso)


class PaymentOrder(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    razorpay_order_id: str
    business_id: str
    user_id: str
    plan: str
    amount_inr: int
    status: str = "created"  # created | paid | failed
    created_at: str = Field(default_factory=now_iso)


class Invoice(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: f"inv_{uuid.uuid4().hex[:10]}")
    invoice_number: str  # GST-compliant sequential number, e.g. "INV-2025-26-000001" -- see invoicing.py
    document_type: str = "tax_invoice"  # tax_invoice | credit_note
    business_id: str
    user_id: str
    plan: str
    description: Optional[str] = None
    status: str = "paid"  # paid | refunded | partially_refunded
    provider: str = "razorpay"
    razorpay_order_id: Optional[str] = None
    razorpay_payment_id: Optional[str] = None
    refund_amount_paise: int = 0
    refunded_at: Optional[str] = None
    hsn_sac_code: str = "998314"
    taxable_value_paise: int = 0
    gst_rate: float = 18.0
    cgst_paise: int = 0
    sgst_paise: int = 0
    igst_paise: int = 0
    total_tax_paise: int = 0
    total_paise: int = 0
    is_intra_state: bool = True
    seller_snapshot: Dict[str, Any] = Field(default_factory=dict)
    buyer_snapshot: Dict[str, Any] = Field(default_factory=dict)
    amount_inr: int = 0  # total_paise/100, kept for older UI code that reads this field directly
    pdf_path: Optional[str] = None
    created_at: str = Field(default_factory=now_iso)


class Message(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    conversation_id: str
    business_id: str
    role: str  # user | assistant | system
    text: str
    confidence: Optional[float] = None
    created_at: str = Field(default_factory=now_iso)


class SupportTicket(BaseModel):
    model_config = ConfigDict(extra="ignore")
    ticket_id: str = Field(default_factory=lambda: f"tkt_{uuid.uuid4().hex[:12]}")
    business_id: str
    owner_user_id: str
    subject: str
    description: str
    priority: str = "medium"  # low | medium | high | critical
    status: str = "open"  # open | in_progress | resolved | closed
    category: str = "general"  # general | technical | billing | feature_request
    admin_response: Optional[str] = None
    resolved_at: Optional[str] = None
    created_at: str = Field(default_factory=now_iso)
    updated_at: str = Field(default_factory=now_iso)


class Notification(BaseModel):
    model_config = ConfigDict(extra="ignore")
    notification_id: str = Field(default_factory=lambda: f"ntf_{uuid.uuid4().hex[:12]}")
    user_id: Optional[str] = None  # null for broadcast to all
    business_id: Optional[str] = None
    target_group: Optional[str] = None  # all | free | paid | specific_business
    title: str
    message: str
    type: str = "info"  # info | warning | announcement | system
    read: bool = False
    read_at: Optional[str] = None
    created_by: Optional[str] = None  # admin user_id
    created_at: str = Field(default_factory=now_iso)


class SalesReferral(BaseModel):
    model_config = ConfigDict(extra="ignore")
    referral_id: str = Field(default_factory=lambda: f"ref_{uuid.uuid4().hex[:12]}")
    sales_user_id: str
    business_id: str
    commission_rate: float = 0.15  # 15%
    total_commission_earned: float = 0.0
    commission_paid: float = 0.0
    pending_commission: float = 0.0
    status: str = "active"  # active | paused | completed
    last_payment_date: Optional[str] = None
    created_at: str = Field(default_factory=now_iso)


class PasswordResetOTP(BaseModel):
    model_config = ConfigDict(extra="ignore")
    otp_id: str = Field(default_factory=lambda: f"otp_{uuid.uuid4().hex[:12]}")
    user_id: str
    email: str
    otp_hash: str
    expires_at: str
    used: bool = False
    created_at: str = Field(default_factory=now_iso)
